FLOATING WORLDS - ONCEMORE UPDATED HANDOFF

This is the current /floating-worlds experience, packaged as a standalone static site.
The original Floating Worlds v5.zip has not been changed.

RUN IT
1. Extract every file into the same folder.
2. Serve that folder with any static HTTP server. No Next.js app or build step is required.
   Example (Python installed): python3 -m http.server 8000
   Windows alternative: py -m http.server 8000
3. Open http://localhost:8000 in a browser with WebGL support.

Do not open index.html directly with a file:// URL; browser module loading requires HTTP.
Google Fonts are fetched online, with local system font fallbacks. All scene assets and JavaScript are included.

CONTENTS
- index.html: page, interface and styles
- app.js: bundled renderer, flight controls, look presets and saved settings
- world-layout.js: perspective layout and cloud route
- atmosphere.js: island atmosphere and environment effects
- cloud-road.js: dense cloud path and visibility control
- Image, depth, normal and cloud textures, including desktop/mobile variants
- cloud-billows-v1.png / .txt: cloud artwork source and generation notes

LOOK POPUP
Choose Dusk, Storm, Golden hour, Bright, Blue hour or Artwork.
Hide dense cloud path removes the added path while keeping the surrounding atmosphere.
Enable edge vignette switches the edge darkening on/off; Vignette strength adjusts its intensity.
Look values and both switches persist in the browser. Copy settings includes their current states.
Reset restores the default Dusk look, shows the cloud path and enables the vignette.

PACKAGING NOTE
The only runtime difference from apps/web/public/floating-worlds is the base URL in index.html:
it is ./ here instead of /floating-worlds/, so the package works at a server root or in a subfolder.
No scene, camera, animation, shader, texture or look values have been changed for packaging.

The existing bundled third-party license notices remain in app.js.
